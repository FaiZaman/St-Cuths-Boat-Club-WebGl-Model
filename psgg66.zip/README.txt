St Cuth's Boat Club

To run the application, open the html file (my_model.html)
IMPORTANT: Open with Firefox and no other browser!

Controls - Moving around

W - Move forwards
A - Move left
S - Move backwards
D - Move right
Left Shift - Move down
Spacebar - Move up

Controls - Looking around

Up Arrow - Look up
Down Arrow - Look down
Left Arrow - Look left
Right Arrow - Look right

Controls - Moving objects

F - Toggle opening/closing of fence
G - Toggle opening/closing of main sliding doors (on the side)

Moving the camera around is one of my main application features. It enables you to get close to the models and look at them more easily.
You can also move around the back, where there are sliding doors

NB: Sometimes the program crashes after being active in Firefox for a period of time. If this happens, simply relaunch the application.